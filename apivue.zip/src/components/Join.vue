<template>
  <div>
    <h1>{{ text }}</h1>
    <form action="">
      <label for="num">번호
        <input type="text" id="num" name="num" v-model="num" />
      </label>
      <label for="title">제목
        <input type="text" id="title" name="title" v-model="title" />
      </label>
      <label for="content">내용
        <input type="text" id="content" name="content" v-model="content" />
      </label>
      <label for="writerEmail">작성자
        <input type="text" id="writerEmail" name="writerEmail" v-model="writerEmail" />
      </label>
      <label for="">
        <input type="button" @click="join" value="회원가입" />
      </label>
    </form>
  </div>
</template>

<script>
export default {
  name: 'TheJoin',
  data() {
    return {
      text: 'Join Page',
      num: '',
      title: '',
      content: '',
      writerEmail: ''
    }
  },
  methods: {

  }
}
</script>

<style>
label {
  display: block;
}
</style>