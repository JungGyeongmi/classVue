<template>
  <div>
    <h1>{{ text }}</h1>
  </div>
</template>

<script>
export default {
  name: 'TheList',
  data() {
    return {
      text: 'TheList'
    }
  }
}
</script>

<style>

</style>