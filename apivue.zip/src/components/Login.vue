<template>
  <div>
    <h1>{{ text }}</h1>
  </div>
</template>

<script>
export default {
  name: 'TheLogin',
  data() {
    return {
      text: 'Login Page'
    }
  }
}
</script>

<style>

</style>