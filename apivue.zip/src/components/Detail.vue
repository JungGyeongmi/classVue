<template>
  <div>
    <h1>{{ text }}</h1>
  </div>
</template>

<script>
export default {
  name: 'TheDetail',
  data() {
    return {
      text: 'TheDetail'
    }
  }
}
</script>

<style>

</style>