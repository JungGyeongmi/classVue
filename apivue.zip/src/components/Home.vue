<template>
  <div class="sample">
    <input type="text" v-model="text"><br>{{ text }}<br>
    <input @click="clickBtn" type="button" :value="text">
  </div>
</template>

<script>
export default {
  name: 'ToHome',
  methods: {
    clickBtn() {
      console.log("Home Button.")
    }
  },
  data() {
    return {
      text: 'Home 샘플입니당'
    }
  }
}
</script>

<style>
.sample {
  overflow:auto
}
</style>