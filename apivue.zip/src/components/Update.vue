<template>
  <div>
    <h1>{{ text }}</h1>
  </div>
</template>

<script>
export default {
  name: 'TheUpdate',
  data() {
    return {
      text: 'TheUpdate'
    }
  }
}
</script>

<style>

</style>