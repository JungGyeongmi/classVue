<template>
  <div id="nav">
    <ul>
      <li>
        <router-link to="/">Home</router-link>
      </li>
      <li>
        <router-link to="/join">회원 가입</router-link>
      </li>
      <li>
        <router-link to="/login">Login</router-link>
      </li>
      <li>
        <router-link to="/list">회원 목록</router-link>
      </li>
      <li>
        <router-link to="/update">회원 수정</router-link>
      </li>
      <li>
        <router-link to="/delete">회원 삭제</router-link>
      </li>
      <li>
        <router-link to="/detail">회원 상세(My Page)</router-link>
      </li>
    </ul>
    <br>

    <div>
      <router-view />
    </div>
  </div>
</template>

<script>

export default {
  
}
</script>

<style>
ul {
  list-style: none;
}
li {
  display: inline-block;
  width: 150px;
}
</style>
